/**
 * Created by hqh on 2020/5/21.
 * 对外暴露 dtPrint 打印方法 传入打印内容跟相关参数，
 * 在此方法内部做系统检测 调用不同的客户端
 */
(function() {
  window.dtPrint = {
    isWin: (navigator.platform == "Win32") || (navigator.platform == "Windows"),
    isLinux: (String(navigator.platform).indexOf("Linux") > -1),
    // 提供一套跟 lodup一样的api
    getLodop() {
      return this;
    },
    PRINT_INIT() {},
    SET_PRINT_PAGESIZE() {},
    ADD_PRINT_HTM() {},
    PREVIEW() {},
  };
})();
