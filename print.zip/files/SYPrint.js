/* @SYPrint.js
 * js打印
 * 2020-05-07
 */
(function (window, document) {
    var printBtnIframeStyle = "body{margin: 0; text-align: center; background: #eee;}div{border-bottom: 1px solid #aaa; padding: 2px 0;}button{cursor: pointer; font-size:14px; line-height: 22px; border: 1px solid #aaa; width: 46px; display: inline-block;}"; // 打印按钮样式
    var printViewIfram;
    var printBtnIframe;
    var isIE = (navigator.userAgent.indexOf('MSIE') >= 0) || (navigator.userAgent.indexOf('Trident') >= 0);

    var Print = function (dom, options) {
        if (!(this instanceof Print)) return new Print(dom, options);
        var style = document.createElement("style");
        style.id = 'printStyle';
        style.innerHTML = '@media print { @page { size: A4; width: 21cm; margin: 0; }  @page:left {margin-left: 3cm;} @page:right {margin-right: 3cm;}}';
        document.head.appendChild(style);
        this.options = this.extend({
            noPrint: '.no-print',//不打印区域
            landscape: false,//横向或纵向
            margin: '0',
            onStart: function () {
            },
            onEnd: function () {
            }
        }, options);
        // 根据参数判断，如果第一个字符是“#” 则认为传入的是dom的ID，否则任务是html字符串
        if ((typeof dom) === "string") {
            this.dom = (dom.charAt(0) === '#') ? document.querySelector(dom) : this.toDom(dom);
        } else if ((typeof dom) === "object") {
            this.dom = this.get2many(dom);
        } else {
            this.dom = dom;
        }
        this.init();
    };
    Print.prototype = {
        init: function () {
            var content = this.getStyle() + this.getHtml();
            this.writeIframe(content);
            this.setDocumentPrintStyle();
        },
        get2many: function (dom) {
            return this.toDom('<div>' + dom.join('<div style="page-break-after:always"></div>') + '</div>')
        },
        toDom: function (htmlStr) {
            var objE = document.createElement("div");
            objE.innerHTML = '<div class="page" style="margin:'+ this.options.margin +'"><style></style>'+ htmlStr + '</div>';
            return objE.childNodes[0];
        },
        extend: function (obj, obj2) {
            for (var k in obj2) {
                obj[k] = obj2[k];
            }
            return obj;
        },
        getStyle: function () {
            var str = "",
                styles = document.querySelectorAll('style');
            for (var i = 0; i < styles.length; i++) {
                str += styles[i].outerHTML;
            }
            str += "<style>" + (this.options.noPrint ? this.options.noPrint : '.no-print') + "{display:none;}</style>";
            return str;
        },
        /**
         * 设置打印的 css @media print
         */
        setDocumentPrintStyle() {
        },
        // 获取html内容
        getHtml: function () {
            var inputs = document.querySelectorAll('input');
            var textareas = document.querySelectorAll('textarea');
            var selects = document.querySelectorAll('select');
            for (var k in inputs) {
                if (inputs[k].type === "checkbox" || inputs[k].type === "radio") {
                    if (inputs[k].checked === true) {
                        inputs[k].setAttribute('checked', "checked")
                    } else {
                        inputs[k].removeAttribute('checked')
                    }
                } else if (inputs[k].type === "text") {
                    inputs[k].setAttribute('value', inputs[k].value)
                }
            }
            for (var k2 in textareas) {
                if (textareas[k2].type === 'textarea') {
                    textareas[k2].innerHTML = textareas[k2].value
                }
            }
            for (var k3 in selects) {
                if (selects[k3].type === 'select-one') {
                    var child = selects[k3].children;
                    for (var i in child) {
                        if (child[i].tagName === 'OPTION') {
                            if (child[i].selected === true) {
                                child[i].setAttribute('selected', "selected")
                            } else {
                                child[i].removeAttribute('selected')
                            }
                        }
                    }
                }
            }
            return this.dom.outerHTML;
        },
        // 生成预览的iframe
        writeIframe: function (content) {
          var $this = this;
          var viewWin, winDoc, iframe = document.createElement('iframe'),
              viewIframe = document.body.appendChild(iframe);
          iframe.id = "myIframe";
          printViewIfram = iframe;
          // 打印预览
          viewWin = viewIframe.contentWindow;
          winDoc = viewWin.document;
          // 打开一个要写入的文档
          winDoc.open();
          winDoc.write(content);
          winDoc.close();
          // 真实打印按钮
          printBtnIframe = document.createElement('iframe');
          document.body.appendChild(printBtnIframe);
          var printBtnIframeDoc = printBtnIframe.contentWindow.document;
          printBtnIframeDoc.write('<style>' + printBtnIframeStyle + '</style><div><button id="print">打印</button>&nbsp;<button id="close">关闭</button></div>');
          this.setViewIframe();
          var oldBodyOverflow = document.body.style.overflow;
          document.body.style.overflow = 'hidden';
          printBtnIframeDoc.getElementById('print').onclick = function() {
            // 调用打印
            $this.toPrint(viewWin, function () {
              $this.closwPrintView(oldBodyOverflow);
            });
          };
          // 关闭打印
          printBtnIframeDoc.getElementById('close').onclick = function() {
            $this.closwPrintView(oldBodyOverflow);
          };
        },
        /**
         * 打印预览关闭
         */
        closwPrintView: function(oldBodyOverflow) {
          document.body.style.overflow = oldBodyOverflow;
          document.body.removeChild(printViewIfram);
          document.body.removeChild(printBtnIframe);
          document.head.removeChild(document.getElementById('printStyle'));
        },
        /**
         * 打印预览
         */
        setViewIframe: function(){
          // 预览iframe显示 21cm*29.7cm
          printViewIfram.style.border = "none";
          printViewIfram.style.background = "#fff";
          printViewIfram.style.zIndex = '99999';
          printViewIfram.style.position = 'fixed';
          // 横纵向预览差异
          if (this.options.landscape) {
            printViewIfram.style.width = '29.7cm';
            printViewIfram.style.marginLeft = '-14.85cm';
          } else {
            printViewIfram.style.width = '21cm';
            printViewIfram.style.marginLeft = '-10.5cm';
          }
          printViewIfram.style.top = '32px';
          printViewIfram.style.left = '0px';
          var printH = document.documentElement.clientHeight  - 32; // 预览高度
          printViewIfram.style.height = printH + "px";
          printViewIfram.style.left = '50%';
          printViewIfram.style.border = '1px solid #000';
          // 按钮iframe显示
          printBtnIframe.style.border = 'none';
          printBtnIframe.style.background = '#fff';
          printBtnIframe.style.zIndex = '99999';
          printBtnIframe.style.position = 'fixed';
          printBtnIframe.style.width = '100%';
          printBtnIframe.style.height = '31px';
          printBtnIframe.style.top = '0px';
          printBtnIframe.style.left = '0px';
        },
        // 执行打印方法
        toPrint: function (w, cb) {
            var _this = this;
            try {
                console.log(w);
                setTimeout(function () {
                    w.focus();
                    typeof _this.options.onStart === 'function' && _this.options.onStart();
                    _this.resetPrint();
                    // document.execCommand 做编辑器时候 比如设置选中 光标位置字体颜色等，还有复制功能。
                    // https://developer.mozilla.org/zh-CN/docs/Web/API/Document/execCommand
                    if (!w.document.execCommand('print', false, null)) {
                        w.print();
                    }
                    typeof _this.options.onEnd === 'function' && _this.options.onEnd();
                    w.close();
                    // 执行回调函数 移除预览 iframe
                    cb && cb()
                });
            } catch (err) {
                console.log('err', err);
            }
        },
        // 设置横纵向 浏览器支持不是很好
        resetPrint: function() {
            try{
                print.landscape   =  this.options.landscape;// 横向打印
            }catch(e){
              console.error('不支持此方法');
            }
        },
        // 生成打印按钮html
        getPrintButton:function(){
            return '<div style="position:absolute;bottom:0;right:10px;">' +
                '<a id="printBottom" style="width:30px;height:20px;border:1px solid cornflowerblue;cursor:pointer;padding:5px">打印</a>&nbsp;&nbsp;&nbsp;&nbsp;'+
                '<a id="backBottom" style="width:30px;height:20px;border:1px solid cornflowerblue;cursor:pointer;padding:5px">取消</a>'
                '</div>'
        },
        // 绑定按钮事件 真实打印跟关闭按钮
        btnPrint:function(bdhtml){
            document.getElementById('printBottom').onclick = function () {
                window.print(); //调用浏览器的打印功能打印指定区域
                window.document.body.innerHTML = bdhtml; // 最后还原页面
            }
            document.getElementById('backBottom').onclick = function () {
                window.document.body.innerHTML = bdhtml; // 最后还原页面
            }
        },
    };
    window.SYPrint = Print;
}(window, document));
