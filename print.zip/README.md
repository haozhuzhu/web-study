# SYPrint.js 打印插件

#### 使用方法
 1. 引入Print.js
 
		<script src="SYPrint.js"></script>

 2. 调用方法
 

		SYPrint('#Dom',{
			noPrint:'.no-print'
		});
		
 3. 所有参数
 
		noPrint : String 不打印区域,默认'.no-print'
		onStart : Function 打印前回调
		onEnd  : Function 打印后回调（不区分确定/取消）

 4. 指定不打印区域

> 方法一. 添加no-print样式类

		<div class="no-print">不要打印我</div>

> 方法二. 自定义类名

		SYPrint('#Dom',{noPrint:'.do-not-print-me-xxx'});
		
		<div class="do-not-print-me-xxx">不要打印我</div>
		


#### 注意
 1. 不支持background-color背景色打印，试试用background-image代替
 2. 低级浏览器兼容性待验证


